import {Fragment} from "react";
import HomePage from "./home";

const Index = () => {
	return (
		<Fragment>
			<HomePage/>
		</Fragment>
	);
};

export default Index;
