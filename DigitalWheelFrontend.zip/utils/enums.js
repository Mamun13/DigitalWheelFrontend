/**
 *
 * @type {{PKG_FREE_ID: string}}
 */
export const BANNER = {
    ACTIVE: '1',
    DEACTIVE: '2',
}
